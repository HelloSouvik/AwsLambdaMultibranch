package com.sterling.scoring.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateExceptionTranslator;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories("com.sterling.associations")
@PropertySource("classpath:application.properties")
public class DatabaseConfigurationTest {

	private final Logger LOGGER = LoggerFactory.getLogger(DatabaseConfiguration.class);

	@Value("${db.dbDriverClass}")
	private String dbDriverClass;
	@Value("${db.dbURL}")
	private String dbURL;
	@Value("${db.dbUserName}")
	private String dbUserName;
	@Value("${db.dbPassword}")
	private String dbPassword;
	@Value("${db.hibernateShowSQL}")
	private String hibernateShowSQL;
	@Value("${db.hibernateDialect}")
	private String hibernateDialect;

	/*
	 * @Bean public DataSource dataSource() { return new
	 * EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.HSQL)
	 * .addScript("classpath:sql/schema.sql")
	 * .addScript("classpath:sql/import-users.sql") .build(); }
	 */

	Properties hibernateProps() {
		Properties properties = new Properties();
		properties.setProperty("hibernate.dialect", hibernateDialect);
		properties.setProperty("hibernate.show_sql", hibernateShowSQL);
//		properties.setProperty("hibernate.hbm2ddl.auto", "create");
		return properties;
	}

	@Bean
	DataSource dataSource() {
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setUrl(dbURL);
		ds.setUsername(dbUserName);
		ds.setPassword(dbPassword);
		ds.setDriverClassName(dbDriverClass);
		return ds;
	}

	@Bean
	public PlatformTransactionManager transactionManager() {

		JpaTransactionManager txManager = new JpaTransactionManager();
		txManager.setEntityManagerFactory(entityManagerFactory().getObject());
		return txManager;
	}

	@Bean
	public HibernateExceptionTranslator hibernateExceptionTranslator() {
		return new HibernateExceptionTranslator();
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {

		// will set the provider to 'org.hibernate.ejb.HibernatePersistence'
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		// will set hibernate.show_sql to 'true'
//		vendorAdapter.setShowSql(true);
		// if set to true, will set hibernate.hbm2ddl.auto to 'update'
//		vendorAdapter.setGenerateDdl(true);

		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
		factory.setJpaVendorAdapter(vendorAdapter);
		factory.setPackagesToScan("com.sterling.scoring");
		factory.setDataSource(dataSource());
		factory.setJpaProperties(hibernateProps());
		// This will trigger the creation of the entity manager factory
		factory.afterPropertiesSet();

		return factory;
	}
}
