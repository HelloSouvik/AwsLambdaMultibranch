package com.sterling.scoring.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.sterling.scoring.config.ApplicationPropertiesTest;
import com.sterling.scoring.config.ConstantsTest;
import com.sterling.scoring.config.DatabaseConfigurationTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ComponentScan("com.sterling.scoring")
@ContextConfiguration(classes = { ApplicationPropertiesTest.class, DatabaseConfigurationTest.class,
		ConstantsTest.class })
public class ScoringServiceIntTest {

	@Before
	public void setup() {

	}

	@Test
	public void addTest() {
		System.out.println("Hello Moto");
	}
}
