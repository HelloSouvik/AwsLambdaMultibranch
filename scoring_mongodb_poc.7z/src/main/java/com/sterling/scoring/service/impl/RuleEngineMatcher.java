package com.sterling.scoring.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.sterling.scoring.model.ParamGroup;
import com.sterling.scoring.model.ScoringConfigDbMapper;
import com.sterling.scoring.model.ScoringRequest;

@Component
public class RuleEngineMatcher {
	
	private static Logger LOGGER = LoggerFactory.getLogger(ScoringRequestProcessorImpl.class);
	
	public ScoringRequest doCompare(ScoringConfigDbMapper scoringConfigDbMapper, ScoringRequest scoringRequest) {
		if(scoringConfigDbMapper.getCriminalRuleConfig() != null) {
			if(!CollectionUtils.isEmpty(scoringConfigDbMapper.getCriminalRuleConfig().getParamGroup())) {
//				no role has been configured
				for(ParamGroup paramGroup: scoringConfigDbMapper.getCriminalRuleConfig().getParamGroup()) {
					paramGroupIterator(paramGroup);
				}
			}
		}else {
//			no role has been configured
		}
		return scoringRequest;
	}
	
	private void paramGroupIterator(ParamGroup paramGroup) {
		
	}
}
