package com.sterling.scoring.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sterling.scoring.model.ScoringConfigDbMapper;
import com.sterling.scoring.model.ScoringRequest;
import com.sterling.scoring.service.ScoringRequestProcessor;
import com.sterling.scoring.service.ScoringRuleLoader;

@Service
public class ScoringRequestProcessorImpl implements ScoringRequestProcessor {
	private static Logger LOGGER = LoggerFactory.getLogger(ScoringRequestProcessorImpl.class);
	
	@Autowired
	private ScoringRuleLoader scoringRuleLoader;
	
	@Autowired
	RuleEngineMatcher ruleEngineMatcher;

	@Override
	public ScoringRequest doScoring(ScoringRequest scoringRequest) {
		ScoringConfigDbMapper scoringConfigDbMapper = loadScoringRules(scoringRequest);
		if(scoringConfigDbMapper != null) {
			scoringRequest = ruleEngineMatcher.doCompare(scoringConfigDbMapper, scoringRequest);
		}else {
			
		}
		return scoringRequest;
	}

	private ScoringConfigDbMapper loadScoringRules(ScoringRequest scoringRequest) {
		return scoringRuleLoader.loadScoringRules(scoringRequest);
	}

}
