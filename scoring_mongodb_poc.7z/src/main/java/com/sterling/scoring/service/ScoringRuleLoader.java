package com.sterling.scoring.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sterling.scoring.model.ScoringConfigDbMapper;
import com.sterling.scoring.model.ScoringRequest;

@Component
public class ScoringRuleLoader {
	private static Logger LOGGER = LoggerFactory.getLogger(ScoringRuleLoader.class);

	public ScoringConfigDbMapper loadScoringRules(ScoringRequest scoringRequest) {
		ScoringConfigDbMapper scoringConfigDbMapper = loadRuleByProduct(scoringRequest);
		if(scoringConfigDbMapper == null) {
			scoringConfigDbMapper = loadRuleByProductCategory(scoringRequest);
			if(scoringConfigDbMapper == null) {
				scoringConfigDbMapper = loadRuleByJurisdiction(scoringRequest);
			}
		}
		return scoringConfigDbMapper;
	}
	
	public ScoringConfigDbMapper loadScoringRulesBySrn(ScoringRequest scoringRequest) {
		return loadRuleBySrn(scoringRequest);
	}

	private ScoringConfigDbMapper loadRuleByProductCategory(ScoringRequest scoringRequest) {
		return null;
	}

	private ScoringConfigDbMapper loadRuleByProduct(ScoringRequest scoringRequest) {
		return null;
	}

	private ScoringConfigDbMapper loadRuleByJurisdiction(ScoringRequest scoringRequest) {
		return null;
	}
	
	private ScoringConfigDbMapper loadRuleBySrn(ScoringRequest scoringRequest) {
		return null;
	}
}
