package com.sterling.scoring.service;

import com.sterling.scoring.model.ScoringRequest;

public interface ScoringRequestProcessor {
	public ScoringRequest doScoring(ScoringRequest scoringRequest);
}
