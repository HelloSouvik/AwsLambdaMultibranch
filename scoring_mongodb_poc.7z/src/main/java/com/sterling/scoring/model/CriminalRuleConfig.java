package com.sterling.scoring.model;

import java.util.ArrayList;

public class CriminalRuleConfig {
	private ArrayList<ParamGroup> paramGroup;

	public ArrayList<ParamGroup> getParamGroup() {
		return paramGroup;
	}

	public void setParamGroup(ArrayList<ParamGroup> paramGroup) {
		this.paramGroup = paramGroup;
	}

}
