package com.sterling.scoring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.databind.ObjectMapper;

@Table(name = "scoring_config")
@Entity
public class ScoringConfigDbMapper {
	@Id()
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_associations_id")
	private Long id;
	@Column(name = "product_category", nullable = true, length = 200)
	private String productCategory;
	@Column(name = "product", nullable = true, length = 200)
	private String product;
	@Column(name = "rule_config_json", nullable = true, length = 200)
	private String ruleConfigStr;
	@Transient
	private CriminalRuleConfig criminalRuleConfig;
	@Column(name = "jurisdiction", nullable = true, length = 200)
	private String jurisdiction;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getRuleConfigStr() {
		return ruleConfigStr;
	}

	public void setRuleConfigStr(String ruleConfigStr) {
		this.ruleConfigStr = ruleConfigStr;
	}

	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public CriminalRuleConfig getCriminalRuleConfig() {
		ObjectMapper mapper = new ObjectMapper();
		try {
			this.criminalRuleConfig = mapper.readValue(ruleConfigStr , CriminalRuleConfig.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return criminalRuleConfig;
	}

	public void setCriminalRuleConfig(CriminalRuleConfig criminalRuleConfig) {
		this.criminalRuleConfig = criminalRuleConfig;
	}

}
