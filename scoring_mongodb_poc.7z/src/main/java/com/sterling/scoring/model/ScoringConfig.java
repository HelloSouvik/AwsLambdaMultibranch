package com.sterling.scoring.model;

public class ScoringConfig {
	private String srn;
	private String productCategory;
	private String product;
	private CriminalRuleConfig criminalRuleConfig;

	public String getSrn() {
		return srn;
	}

	public void setSrn(String srn) {
		this.srn = srn;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public CriminalRuleConfig getCriminalRuleConfig() {
		return criminalRuleConfig;
	}

	public void setCriminalRuleConfig(CriminalRuleConfig criminalRuleConfig) {
		this.criminalRuleConfig = criminalRuleConfig;
	}

}
