package com.sterling.scoring.model;

import java.util.ArrayList;

public class GroupDefinition {
	private String name;
	private String type;
	private ArrayList<Object> values;
	private String operator;
	private boolean isEmptyCheck;
	private String level;
	private int sequence;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ArrayList<Object> getValues() {
		return values;
	}

	public void setValues(ArrayList<Object> values) {
		this.values = values;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public boolean isEmptyCheck() {
		return isEmptyCheck;
	}

	public void setEmptyCheck(boolean isEmptyCheck) {
		this.isEmptyCheck = isEmptyCheck;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

}
