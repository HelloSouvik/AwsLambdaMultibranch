package com.sterling.scoring.model;

import java.util.ArrayList;

public class CrimCase {
	private String familyName;
	private String givenName;
	private String dob;
	private String dispositionDate;
	private String arrestDate;
	private ArrayList<String> missing;
	private ArrayList<CrimCharge> charges;

	public ArrayList<CrimCharge> getCharges() {
		return charges;
	}

	public void setCharges(ArrayList<CrimCharge> charges) {
		this.charges = charges;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getDispositionDate() {
		return dispositionDate;
	}

	public void setDispositionDate(String dispositionDate) {
		this.dispositionDate = dispositionDate;
	}

	public String getArrestDate() {
		return arrestDate;
	}

	public void setArrestDate(String arrestDate) {
		this.arrestDate = arrestDate;
	}

	public ArrayList<String> getMissing() {
		return missing;
	}

	public void setMissing(ArrayList<String> missing) {
		this.missing = missing;
	}

}
