package com.sterling.scoring.model;

import java.util.ArrayList;

public class ParamGroup {
	private ArrayList<GroupDefinition> groupDefinition;

	public ArrayList<GroupDefinition> getGroupDefinition() {
		return groupDefinition;
	}

	public void setGroupDefinition(ArrayList<GroupDefinition> groupDefinition) {
		this.groupDefinition = groupDefinition;
	}

}
