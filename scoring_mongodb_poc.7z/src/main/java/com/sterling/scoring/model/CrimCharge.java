package com.sterling.scoring.model;

import java.util.ArrayList;

public class CrimCharge {
	private String chargeLevel;
	private String dispositionType;
	private String arrestDate;
	private String ruleDecision;
	private ArrayList<String> missing;

	public String getChargeLevel() {
		return chargeLevel;
	}

	public void setChargeLevel(String chargeLevel) {
		this.chargeLevel = chargeLevel;
	}

	public String getDispositionType() {
		return dispositionType;
	}

	public void setDispositionType(String dispositionType) {
		this.dispositionType = dispositionType;
	}

	public String getArrestDate() {
		return arrestDate;
	}

	public void setArrestDate(String arrestDate) {
		this.arrestDate = arrestDate;
	}

	public String getRuleDecision() {
		return ruleDecision;
	}

	public void setRuleDecision(String ruleDecision) {
		this.ruleDecision = ruleDecision;
	}

	public ArrayList<String> getMissing() {
		return missing;
	}

	public void setMissing(ArrayList<String> missing) {
		this.missing = missing;
	}

}
