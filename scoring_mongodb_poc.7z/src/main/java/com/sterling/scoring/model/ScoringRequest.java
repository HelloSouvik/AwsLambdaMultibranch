package com.sterling.scoring.model;

import java.util.ArrayList;

public class ScoringRequest {
	private String familyName;
	private String dob;
	private String ssn;
	private String rule;
	private ArrayList<CrimCase> cases;

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public ArrayList<CrimCase> getCases() {
		return cases;
	}

	public void setCases(ArrayList<CrimCase> cases) {
		this.cases = cases;
	}

}
