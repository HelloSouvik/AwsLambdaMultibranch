/**
 * JPA domain objects.
 */
package com.sterling.scoring.model;
