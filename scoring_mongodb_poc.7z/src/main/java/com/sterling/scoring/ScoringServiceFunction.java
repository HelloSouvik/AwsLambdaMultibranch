package com.sterling.scoring;

import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component("scoringServiceFunction")
public class ScoringServiceFunction implements Function<Object, Object> {

	private static Logger LOGGER = LoggerFactory.getLogger(ScoringServiceFunction.class);

	@Override
	public Object apply(Object object) {
		return null;
	}
}
