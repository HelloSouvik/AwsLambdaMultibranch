package com.sterling.scoring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sterling.scoring.model.ScoringConfigDbMapper;

public interface ScoringConfigDbMapperRepository extends JpaRepository<ScoringConfigDbMapper, Long>{
	/*
	 * Association findByPkId(Long pkId); List<Association>
	 * findByReferenceValuesIn(List<Reference> referenceView); Association
	 * findById(String id);
	 */
}
