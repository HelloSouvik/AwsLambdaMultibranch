package com.sterling.scoring.dao.impl;

import org.springframework.stereotype.Repository;

import com.sterling.scoring.dao.ScoringDAO;

@Repository
public class ScoringDAOImpl implements ScoringDAO {

}
