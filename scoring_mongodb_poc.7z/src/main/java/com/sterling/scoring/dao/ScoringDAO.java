package com.sterling.scoring.dao;

public interface ScoringDAO {


}
