package com.sterling.poc.mongo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.sterling.poc.mongo.config.test.MongoConfigTest;


@RunWith(SpringJUnit4ClassRunner.class)
@ComponentScan("com.sterling.poc.mongo")
@ContextConfiguration(classes = { MongoConfigTest.class })
@EnableTransactionManagement
@PropertySource("classpath:application.properties")
public class SpringExpressionUTest {

	private static Logger LOGGER = LoggerFactory.getLogger(SpringExpressionUTest.class);
	
	@Test
	public void spelTest() {
		ExpressionParser parser = new SpelExpressionParser();
		Expression exp = parser.parseExpression("'Hello World'");
		String message = (String) exp.getValue();
		System.out.println(message);
		LOGGER.info(message);
	}

	List<String> workers = new ArrayList<String>();
    Map<String, Integer> salaryByWorkers = new HashMap<>();
    
	@Test
	public void spelOneTest() {
		String someTest = "Souvik";
	    workers.add("John");
        workers.add("Susie");
        workers.add("Alex");
        workers.add("George");
 
        salaryByWorkers.put("John", 35000);
        salaryByWorkers.put("Susie", 47000);
        salaryByWorkers.put("Alex", 12000);
        salaryByWorkers.put("George", 14000);
        
        ExpressionParser parser = new SpelExpressionParser();
		Expression exp = parser.parseExpression("workers['John']");
		System.out.println(exp.getValue());
	}
}
