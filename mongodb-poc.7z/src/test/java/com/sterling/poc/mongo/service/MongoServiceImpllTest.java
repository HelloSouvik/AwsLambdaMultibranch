package com.sterling.poc.mongo.service;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.sterling.poc.mongo.config.test.MongoConfigTest;


@RunWith(SpringJUnit4ClassRunner.class)
@ComponentScan("com.sterling.poc.mongo")
@ContextConfiguration(classes = { MongoConfigTest.class })
@EnableTransactionManagement
@PropertySource("classpath:application.properties")
public class MongoServiceImpllTest {

	private static Logger LOGGER = LoggerFactory.getLogger(MongoServiceImpllTest.class);
	
	@Autowired
	MongoServiceImpl mongoServiceImpl;

	@Test
	public void contextLoads() throws JsonParseException, JsonMappingException, IOException, Exception {
		mongoServiceImpl.createData();
	}
}
