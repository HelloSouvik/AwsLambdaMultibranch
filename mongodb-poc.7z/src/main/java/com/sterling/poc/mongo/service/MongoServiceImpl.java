package com.sterling.poc.mongo.service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sterling.poc.mongo.model.ScoringRule;
import com.sterling.poc.mongo.repository.ScoringRuleRepository;

@Component
public class MongoServiceImpl {
	@Autowired
	ScoringRuleRepository scoringRuleRepository;

	public void createData() throws JsonParseException, JsonMappingException, IOException, Exception {
		ScoringRule rule = steringToJson(readJsonFile());
		scoringRuleRepository.save(rule);
	}

	public void readData() {
		
	}

	public void updateData() {
		
	}

	public void deleteData() {
		
	}
	
	private ScoringRule steringToJson(String data) throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		ScoringRule bj = objectMapper.readValue(data, ScoringRule.class);
		return bj;
	}
	
	private String readJsonFile() throws Exception {
		File file = FileUtils.getFile(getClass().getClassLoader().getResource("data/data.json").getPath());
		File tempDir = FileUtils.getTempDirectory();
		FileUtils.copyFileToDirectory(file, tempDir);
		File newTempFile = FileUtils.getFile(tempDir, file.getName());
		String data = FileUtils.readFileToString(newTempFile, Charset.defaultCharset());
		System.out.println(data);
		return data;
	}

}
