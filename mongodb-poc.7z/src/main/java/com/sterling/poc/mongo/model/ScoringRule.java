package com.sterling.poc.mongo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ScoringRule")
public class ScoringRule {
	@Id
    private String id;
	private String product;
	private String productCategory;
	private CriminalRuleConfig criminalRuleConfig;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public CriminalRuleConfig getCriminalRuleConfig() {
		return criminalRuleConfig;
	}

	public void setCriminalRuleConfig(CriminalRuleConfig criminalRuleConfig) {
		this.criminalRuleConfig = criminalRuleConfig;
	}
}
