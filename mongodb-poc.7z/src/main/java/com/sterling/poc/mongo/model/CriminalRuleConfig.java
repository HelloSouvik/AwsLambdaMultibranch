package com.sterling.poc.mongo.model;

import java.util.ArrayList;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "CriminalRuleConfig")
public class CriminalRuleConfig {
	@Id
	private Long id;
	private ArrayList<ParamGroup> paramGroup;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ArrayList<ParamGroup> getParamGroup() {
		return paramGroup;
	}

	public void setParamGroup(ArrayList<ParamGroup> paramGroup) {
		this.paramGroup = paramGroup;
	}

}
