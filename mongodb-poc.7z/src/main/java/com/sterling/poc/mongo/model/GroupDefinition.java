package com.sterling.poc.mongo.model;

import java.util.ArrayList;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "GroupDefinition")
public class GroupDefinition {
	@Id
    private Long id;
	private String name;
	private ArrayList<String> values;
	private String type;
	private String operator;
	private boolean isEmptyCheck;
	private String level;
	private int sequence;
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}
	
	public boolean getIsEmptyCheck() {
		return isEmptyCheck;
	}

	public void setIsEmptyCheck(boolean isEmptyCheck) {
		this.isEmptyCheck = isEmptyCheck;
	}

	public boolean isEmptyCheck() {
		return isEmptyCheck;
	}

	public void setEmptyCheck(boolean isEmptyCheck) {
		this.isEmptyCheck = isEmptyCheck;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<String> getValues() {
		return values;
	}

	public void setValues(ArrayList<String> values) {
		this.values = values;
	}

}
