package com.sterling.poc.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.sterling.poc.mongo.model.ScoringRule;

public interface ScoringRuleRepository extends MongoRepository<ScoringRule, Long> {

}
