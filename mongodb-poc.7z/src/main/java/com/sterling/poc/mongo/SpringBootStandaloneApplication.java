package com.sterling.poc.mongo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.sterling.poc.mongo.service.MongoServiceImpl;

@SpringBootApplication
@ComponentScan("com.sterling.poc.mongo")
@EnableTransactionManagement
@PropertySource("classpath:application.properties")
public class SpringBootStandaloneApplication implements CommandLineRunner {

	@Autowired
	MongoServiceImpl mongoServiceImpl;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootStandaloneApplication.class, args);
	}

	public void run(String... args) throws Exception {
		System.out.println("Create Entity....");
		mongoServiceImpl.createData();
	}
}
