package com.sterling.poc.mongo.model;

import java.util.ArrayList;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ParamGroup")
public class ParamGroup {
	@Id
	private Long id;
	private ArrayList<GroupDefinition> groupDefinition;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ArrayList<GroupDefinition> getGroupDefinition() {
		return groupDefinition;
	}

	public void setGroupDefinition(ArrayList<GroupDefinition> groupDefinition) {
		this.groupDefinition = groupDefinition;
	}

}
