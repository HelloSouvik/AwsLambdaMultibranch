# SCORING

Business Problem
Currently smartdata has a functionality to validate list of mandatory parameters in the request payload.

Mandatory parameters can be specified for the ProductCategory/Product/Country combination. The level at which the parameters are mandatory are also configured.

During request processing time smartdata application checks all configured parameter in request payload. If any of the mandatory is not present in payload then application marked that particular request as INFO_Needed. Application does not complete any request where mandatory parameter is missing.

This is going to be a game changer project for 2019.

## Development


## Production

## Automation Testing


### Build and Deploy ###

* The [Jenkinsfile](Jenkinsfile) will automatically trigger the build in [Jenkins](https://jenkins1.dev.backgroundcheck.com/job/<need_to_change>/job/<need_to_change>/) and start the deployment in the appropriate AWS environment.

* All feature branches and the develop branch will get deployed to the AWS [develop](https://sterling-dev.signin.aws.amazon.com/console) environment while the release branches will be deployed to the [production](https://sterling-prod.awsapps.com/console) environment.

### Changelog ###

* The changelog can be viewed [here](CHANGELOG.md)