/**
 * Spring Data JPA repositories.
 */
package com.sterling.scoring.repository;
