# Changelog

## [1.0.0] - 2019-05-21
### Added
- adding all new module

[1.0.0]: https://bitbucket.org/twengg/<need_to_change>/compare/v1.0.0..1.0.0
