/**
 * Spring Security configuration.
 */
package com.sterling.scoring.security;
