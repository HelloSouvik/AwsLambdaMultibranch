/**
 * Data Transfer Objects.
 */
package com.sterling.scoring.service.dto;
