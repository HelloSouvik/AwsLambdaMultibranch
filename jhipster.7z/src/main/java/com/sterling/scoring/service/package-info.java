/**
 * Service layer beans.
 */
package com.sterling.scoring.service;
